import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Portfolio from './components/Portfolio';
import Contact from './components/Contact';
import Background from './components/Background';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <main className="relative w-full min-h-screen">
      <Background />
      <Navbar />
      <Hero />
      <Services />
      <Portfolio />
      <Contact />
      <Footer />
    </main>
  );
};

export default App;